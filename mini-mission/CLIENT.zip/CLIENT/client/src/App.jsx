import React from 'react';
import { Routes,Route } from 'react-router-dom';
import './App.css';
import Home from './pages/Home';
import ResetPassWord from './pages/ResetPassWord';
import VerifyEmail from './pages/VerifyEmail';
import Login from './Pages/Login'
import AdminRoute from './pages/AdminRoute';
import AdminDashboard from './pages/AdminDashBoard';
import { ToastContainer } from 'react-toastify';

function App() {
  return (
    <div className=''>
      <ToastContainer/>
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="/login" element={<Login />}/>
        <Route path="/reset-password" element={<ResetPassWord/>}/>
        <Route path="/boss" element={<VerifyEmail/>}/>
        <Route path="/admin" element={<AdminRoute />}>
          <Route index element={<VerifyEmail />} />
       </Route>
       <Route path="/admin/report" element={<AdminDashboard/>}/>



      </Routes>
    </div>
  )
}

export default App