import React, { useContext, useState } from "react";
import { assets } from "../assets/assets";
import { useNavigate } from "react-router-dom";
import { AppContent } from "../Context/AppContext";
import axios from "axios";
import { toast } from "react-toastify";
import { motion, AnimatePresence } from "framer-motion";

function NavBar() {
  const navigate = useNavigate();
  const { userData, BackendUrl, setUserData, setIsLoggedin } = useContext(AppContent);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const sendVerficationOtp = async () => {
    try {
      axios.defaults.withCredentials = true;
      const { data } = await axios.post(BackendUrl + "/api/auth/register");

      if (data.success) {
        navigate("/verify-email");
        toast.success(data.message);
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  const logout = async () => {
    try {
      axios.defaults.withCredentials = true;
      const { data } = await axios.post(BackendUrl + "/api/auth/logout");

      if (data.success) {
        setIsLoggedin(false);
        setUserData(null);
        navigate("/");
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="w-full flex justify-between items-center p-4 sm:px-24 fixed top-0 left-0 z-50
                 bg-gradient-to-r from-indigo-900/80 via-indigo-800/80 to-purple-900/80
                 backdrop-blur-xl shadow-xl"
    >
      {/* Logo */}
      <div className="relative cursor-pointer" onClick={() => navigate("/")}>
        <div className="absolute inset-0 bg-white/40 blur-xl rounded-full scale-150"></div>
        <motion.img
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.97 }}
          src={assets.logo}
          alt="Logo"
          className="relative w-28 drop-shadow-[0_4px_10px_rgba(255,255,255,0.7)]"
        />
      </div>

      {/* Right side */}
      {userData ? (
        <div
          className="relative"
          onMouseEnter={() => setDropdownOpen(true)}
          onMouseLeave={() => setDropdownOpen(false)}
        >
          <motion.div
            whileHover={{ scale: 1.1 }}
            className="w-10 h-10 flex justify-center items-center text-lg
                       rounded-full bg-white text-indigo-700 font-bold shadow-md cursor-pointer"
          >
            {userData.name[0].toUpperCase()}
          </motion.div>

          {/* Dropdown */}
          <AnimatePresence>
            {dropdownOpen && (
              <motion.ul
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-3 bg-white shadow-xl rounded-lg overflow-hidden text-sm z-50"
              >
                {!userData.isAccountVerified && (
                  <li
                    onClick={sendVerficationOtp}
                    className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  >
                    Verify Email
                  </li>
                )}
                {userData.role === "admin" && (
  <li
    onClick={() => navigate("/boss")}
    className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
  >
    Admin Dashboard
  </li>
)}

{userData.role === "participant" && (
  <li
    onClick={() => navigate("/reset-password")}
    className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
  >
    Dashboard
  </li>
)}

                <li
                  onClick={logout}
                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                >
                  Logout
                </li>
              </motion.ul>
            )}
          </AnimatePresence>
        </div>
      ) : (
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate("/login")}
          className="px-5 py-2 bg-white text-indigo-700 rounded-full shadow-lg 
                     flex items-center gap-2 font-medium hover:bg-gray-100"
        >
          Login
          <img className="w-4" src={assets.arrow_icon} alt="" />
        </motion.button>
      )}
    </motion.div>
  );
}

export default NavBar;
