import React, { useContext, useState, useEffect } from "react";
import { AppContent } from "../Context/AppContext";
import { assets } from "../assets/assets";
import { motion } from "framer-motion";

function Header() {
  const { userData } = useContext(AppContent);

  const quotes = [
    "Mark 16:15 — “Go into all the world and preach the gospel to all creation.”",
    "Romans 10:14 — “How can they hear without someone preaching to them?”",
    "Matthew 5:16 — “Let your light shine before others.”",
    "Psalm 96:3 — “Declare His glory among the nations.”",
  ];

  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % quotes.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="
      w-full flex flex-col justify-center items-center gap-4 text-white px-6 py-20
      bg-gradient-to-br from-purple-700 via-indigo-600 to-indigo-500
    ">
      {/* Profile Image */}
      <motion.img
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1 }}
        className="w-40 h-40 rounded-full shadow-xl mt-10 border-4 border-white/50"
        src={assets.header_img}
        alt=""
      />

      {/* Welcome */}
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="text-3xl font-bold drop-shadow-md"
      >
        Hey Christen Student ✝️
      </motion.h2>

      {/* Main Title */}
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="text-4xl sm:text-5xl font-extrabold text-center 
        drop-shadow-[0_0_14px_rgba(255,255,255,0.5)]"
      >
        WELCOME TO THE MISSION
      </motion.h1>

      {/* Bible Quote Slider */}
      <motion.p
        key={index}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="text-center text-lg max-w-2xl font-medium italic px-4 text-white/90"
      >
        {quotes[index]}
      </motion.p>

      {/* Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.94 }}
        className="mt-6 px-6 py-3 bg-white text-indigo-700 font-semibold rounded-full 
        shadow-lg hover:bg-gray-100 transition-all duration-300"
      >
        Get Started
      </motion.button>
    </div>
  );
}

export default Header;
