import { createContext, useState, useEffect } from "react";
import axios from "axios";
import { toast } from "react-toastify";

export const AppContent = createContext();

export const AppContextProvider = ({ children }) => {
  axios.defaults.withCredentials = true;
  const BackendUrl = import.meta.env.VITE_BACKEND_URL;

  const [isLoggedin, setIsLoggedin] = useState(false);
  const [userData, setUserData] = useState(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  const getUserData = async () => {
    try {
      const { data } = await axios.get(BackendUrl + "/api/auth/data");
      if (data.success) setUserData({ ...data.userData, role: data.userData.role });
      else toast.error(data.message);
    } catch (error) {
      toast.error(error.message);
    }
  };

  const getAuthState = async () => {
    try {
      const { data } = await axios.get(BackendUrl + "/api/auth/is-auth");
      if (data.success) {
        setIsLoggedin(true);
        await getUserData();
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoadingAuth(false);
    }
  };

  useEffect(() => {
    getAuthState();
  }, []);

  const value = {
    BackendUrl,
    isLoggedin,
    setIsLoggedin,
    userData,
    setUserData,
    getUserData,
    loadingAuth
  };

  return <AppContent.Provider value={value}>{children}</AppContent.Provider>;
};
