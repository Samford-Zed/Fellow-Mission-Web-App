import React, { useEffect, useState, useContext } from "react";
import { AppContent } from "../Context/AppContext";
import axios from "axios";
import { toast } from "react-toastify";

function AdminDashboard() {
  const { BackendUrl } = useContext(AppContent);
  const [collectedData, setCollectedData] = useState([]);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  // Fetch all collected data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data } = await axios.get(BackendUrl + "/api/admin/collected-data", { withCredentials: true });
        if (data.success) setCollectedData(data.data);
      } catch (err) {
        toast.error(err.response?.data?.message || err.message);
      }
    };
    fetchData();
  }, [BackendUrl]);

  // Filtered & searched data
  const filteredData = collectedData
    .filter(item => !filterStatus || item.status === filterStatus)
    .filter(item => item.name.toLowerCase().includes(search.toLowerCase()));

  // Export to CSV
  const exportCSV = () => {
    const header = ["Name", "Phone", "Address", "Status", "Collected By", "Group"];
    const rows = filteredData.map(d => [
      d.name,
      d.phone,
      d.address,
      d.status,
      d.collectedBy?.name || "",
      d.groupId?.name || ""
    ]);
    const csvContent = [header, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "collected_data.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard - Collected Data</h1>

      <div className="flex gap-4 mb-4">
        <input
          type="text"
          placeholder="Search by name"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="p-2 rounded border border-gray-400"
        />
        <select
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value)}
          className="p-2 rounded border border-gray-400"
        >
          <option value="">All Status</option>
          <option value="Pending">believe</option>
          <option value="Completed">listen</option>
          <option value="Rejected">hope</option>
        </select>
        <button
          onClick={exportCSV}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Export CSV
        </button>
      </div>

      <table className="w-full text-left border-collapse border border-gray-300">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2 border">Name</th>
            <th className="p-2 border">Phone</th>
            <th className="p-2 border">Address</th>
            <th className="p-2 border">Status</th>
            <th className="p-2 border">Collected By</th>
            <th className="p-2 border">Group</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.map(item => (
            <tr key={item._id} className="border-b">
              <td className="p-2 border">{item.name}</td>
              <td className="p-2 border">{item.phone}</td>
              <td className="p-2 border">{item.address}</td>
              <td className="p-2 border">{item.status}</td>
              <td className="p-2 border">{item.collectedBy?.name}</td>
              <td className="p-2 border">{item.groupId?.name}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default AdminDashboard;
