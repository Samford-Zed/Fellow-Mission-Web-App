import React, { useContext, useState } from 'react'
import { assets } from '../assets/assets'
import { useNavigate } from 'react-router-dom';
import { AppContent } from '../Context/AppContext';
import axios from 'axios';
import { toast } from 'react-toastify';

function Login() {

  const navigate=useNavigate();
  const {BackendUrl,setIsLoggedin,getUserData}=useContext(AppContent)

  const [state,setState]=useState("Sign Up");
  const [name,setName]=useState("");
  const [password,setPassword]=useState("");
  const [email,setEmail]=useState("");
  const [userData,setUserData]=useState("");
  const [phone,setPhone]=useState("");


  
  

  const onSubmitHandler = async (e) => {
  e.preventDefault();
  try {
    axios.defaults.withCredentials = true;

    let response;

    // SIGN UP
    if (state === "Sign Up") {
      response = await axios.post(BackendUrl + "/api/auth/register", {
        name,
        email,
        password,
        phone
      });
    }
    // LOGIN
    else {
      response = await axios.post(BackendUrl + "/api/auth/login", {
        email,
        password
      });
    }

    if (!response.data.success) {
      toast.error(response.data.message);
      return;
    }

    // Store login
    setIsLoggedin(true);

    // Load user data from context
    await getUserData();

    // Now userData is updated in the context
    const role = response.data.role || response.data.user?.role;

    // Redirect by role
    if (role === "admin") {
      navigate("/boss");
    } else {
      navigate("/reset-password");
    }

  } catch (error) {
    toast.error(error.response?.data?.message || error.message);
  }
};


  return (
    <div className='flex justify-center items-center min-h-screen px-6 sm:px-0
    bg-gradient-to-br from-blue-200 to-purple-400'>
        <img onClick={()=>navigate("/")}src={assets.logo} alt="" className='absolute top-5 left-5 sm:left-20
        w-28 sm:w-32 cursor-pointer'/>
        <div className='flex flex-col items-center bg-slate-900 p-10 rounded-lg shadow-lg w-full sm:w-96
        text-indigo-300 text-sm'>
          <h2 className='text-3xl text-white mb-3 font-semibolds'>{state=== "Sign Up"? "Create Account":"Login"}</h2>
          <p className='text-sm mb-6'>{state==="Sign Up" ? "Create Your Account": "Login To Your Account!"}</p>
          <form onSubmit={onSubmitHandler}>

            {state==="Sign Up" &&
             <><div className='flex items-center mb-4 py-3 px-5 bg-[#3B3635] rounded-full gap-3 w-full text-white'>
                <img src={assets.person_icon} alt="" />
                <input onChange={e=> setName(e.target.value)} 
                value={name} type="text" placeholder="Full Name" required className='bg-transparent outline-none'/>
          </div>

          {/* <div className='flex items-center mb-4 py-3 px-5 bg-[#3B3635] rounded-full gap-3 w-full text-white'>
            <img src={assets.mail_icon} alt="" />
            <input onChange={e=> SetRole(e.target.value)} 
                value={email}type="email" placeholder="Role" required className='bg-transparent outline-none'/>
          </div> */}

          <div className='flex items-center mb-4 py-3 px-5 bg-[#3B3635] rounded-full gap-3 w-full text-white'>
            <img src={assets.mail_icon} alt="" />
            <input onChange={e=> setPhone(e.target.value)} 
                value={phone}type="text" placeholder="Phone" required className='bg-transparent outline-none'/>
          </div>
          
        </>}
          <div className='flex items-center mb-4 py-3 px-5 bg-[#3B3635] rounded-full gap-3 w-full text-white'>
            <img src={assets.mail_icon} alt="" />
            <input onChange={e=> setEmail(e.target.value)} 
                value={email}type="email" placeholder="Email" required className='bg-transparent outline-none'/>
          </div>

          

          <div className='flex items-center mb-4 py-3 px-5 bg-[#3B3635] rounded-full gap-3 w-full text-white'>
            <img src={assets.lock_icon} alt="" />
            <input onChange={e=> setPassword(e.target.value)} 
                value={password}
            type="password" placeholder="PassWord" required className='bg-transparent outline-none'/>
          </div>

          
          <button className='w-full bg-gradient-to-r from-indigo-500 to-indigo-900 py-2.5 rounded-full font-medium text-white cursor-pointer'>{state}</button>
        </form>

        {state==="Sign Up" ? (<p className='text-gray-400 mt-4 text-center text-xs'>Already have an account?{" "} 
          <span onClick={()=>setState("Login")}className='text-blue-400 cursor-pointer underline'>Login here</span></p>
             ):(<p className='text-gray-400 mt-4 text-center text-xs'>Do Not  have an account?{" "} <span onClick={()=>setState("Sign Up")} className='text-blue-400 cursor-pointer underline'>Sign Up here</span></p>
)}


        </div>
        
    </div>
  )
}

export default Login