import React, { useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContent } from '../Context/AppContext';
import axios from 'axios';
import { toast } from 'react-toastify';

function Login() {
  const navigate = useNavigate();
  const { BackendUrl, userData } = useContext(AppContent);

  // Form fields
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [status, setStatus] = useState("");

  // Auto-filled fields
  const [groupId, setGroupId] = useState("");
  const [collectedBy, setCollectedBy] = useState("");

  // User group info (for showing members)
  const [myGroup, setMyGroup] = useState(null);

  // -----------------------------------------
  // 1️⃣ FETCH USER GROUP AUTOMATICALLY
  // -----------------------------------------
  useEffect(() => {
    const fetchGroup = async () => {
      try {
        axios.defaults.withCredentials = true;

        const { data } = await axios.get(BackendUrl + "/api/user/my-group");

        if (data.success && data.group) {
          setGroupId(data.group._id); // Auto set groupId
          setMyGroup(data.group);
        }
      } catch (err) {
        toast.error("Could not load your group.");
      }
    };

    fetchGroup();
  }, [BackendUrl]);

  // -----------------------------------------
  // 2️⃣ SET collectedBy = logged-in user's ID
  // -----------------------------------------
  useEffect(() => {
    if (userData?._id) {
      setCollectedBy(userData._id); // Auto set collectedBy
    }
  }, [userData]);


  // -----------------------------------------
  // 3️⃣ SUBMIT FORM
  // -----------------------------------------
  const onSubmitHandler = async (e) => {
    e.preventDefault();

    try {
      axios.defaults.withCredentials = true;

const { data } = await axios.post(
  BackendUrl + "/api/auth/fill-form",
  {
    groupId: myGroup._id,       // from fetched group
    collectedBy: userData._id,  // current user id from context
    name,
    address,
    phone,
    status,
  }
);


      if (data.success) {
        toast.success("Person added successfully!");

        // Clear form
        setName("");
        setAddress("");
        setPhone("");
        setStatus("");

        // Refresh group members list
        const g = await axios.get(BackendUrl + "/api/user/my-group");
        if (g.data.success) setMyGroup(g.data.group);
      }
    } catch (error) {
      toast.error(error.response?.data?.message || error.message);
    }
  };

  return (
    <div className='flex justify-center items-start min-h-screen px-6 sm:px-0 pt-20 bg-gradient-to-br from-blue-200 to-purple-400'>
      <div className='w-full sm:w-96 flex flex-col items-center gap-6'>

        {/* Group Info Display */}
        {myGroup ? (
          <div className='bg-gray-800 text-white p-4 rounded-lg w-full'>
            <h3 className='text-lg font-bold mb-2'>Your Group: {myGroup.name}</h3>
            <p>Max Members: {myGroup.maxMembers}</p>

            <p className='mt-2 font-semibold'>Members:</p>
            <ul className='list-disc pl-5 mt-1'>
              {myGroup.members.map((m) => (
                <li key={m._id}>{m.name} - {m.email} - {m.phone}</li>
              ))}
            </ul>
          </div>
        ) : (
          <p className='text-gray-300 mb-4'>You are not in any group yet.</p>
        )}

        {/* Form */}
        <div className='flex flex-col items-center bg-slate-900 p-6 rounded-lg shadow-lg w-full text-indigo-300 text-sm'>
          <h2 className='text-2xl text-white mb-3 font-semibold'>Add Data Here</h2>

          <form onSubmit={onSubmitHandler} className='w-full space-y-3'>

            {/* Hidden auto fields */}
            <input type="hidden" value={groupId} readOnly />
            <input type="hidden" value={collectedBy} readOnly />

            <input
              type="text"
              placeholder="Full Name"
              value={name}
              onChange={e => setName(e.target.value)}
              className='w-full p-3 rounded-lg bg-[#3B3635] text-white outline-none'
              required
            />

            <input
              type="text"
              placeholder="Address"
              value={address}
              onChange={e => setAddress(e.target.value)}
              className='w-full p-3 rounded-lg bg-[#3B3635] text-white outline-none'
              required
            />

            <input
              type="text"
              placeholder="Phone"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className='w-full p-3 rounded-lg bg-[#3B3635] text-white outline-none'
              required
            />

            <input
              type="text"
              placeholder="Status"
              value={status}
              onChange={e => setStatus(e.target.value)}
              className='w-full p-3 rounded-lg bg-[#3B3635] text-white outline-none'
              required
            />

            <button className='w-full py-2.5 bg-gradient-to-r from-indigo-500 to-indigo-900 rounded-full text-white font-medium'>
              Add Person
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}

export default Login;
