import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import { AppContent } from "../Context/AppContext";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

function VerifyEmail() {
  axios.defaults.withCredentials = true;

  const { BackendUrl, isLoggedin, userData, loadingAuth } = useContext(AppContent);
  const navigate = useNavigate();

  const [groupName, setGroupName] = useState("");
  const [maxMembers, setMaxMembers] = useState(5);
  const [users, setUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loadingData, setLoadingData] = useState(true);

  // -----------------------------
  // LOAD USERS + GROUPS
  // -----------------------------
  const loadUsers = async () => {
    try {
      const { data } = await axios.get(`${BackendUrl}/api/admin/admin/users`);
      setUsers(data);
    } catch (err) {
      toast.error("Cannot load users");
    }
  };

  const loadGroups = async () => {
    try {
      const { data } = await axios.get(`${BackendUrl}/api/admin/admin/groups`);
      if (data.success) setGroups(data.groups);
    } catch (err) {
      toast.error("Cannot load groups");
    }
  };

  // -----------------------------
  // WAIT FOR AUTH BEFORE LOADING DATA
  // -----------------------------
  useEffect(() => {
    if (loadingAuth) return; // wait until auth check finished
    if (!isLoggedin || userData?.role !== "admin") {
      navigate("/");
      return;
    }
    const fetchData = async () => {
      setLoadingData(true);
      await loadUsers();
      await loadGroups();
      setLoadingData(false);
    };
    fetchData();
  }, [isLoggedin, userData, loadingAuth]);

  if (loadingAuth || loadingData) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  // -----------------------------
  // CREATE GROUP
  // -----------------------------
  const handleCreateGroup = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.post(`${BackendUrl}/api/admin/admin/groups`, {
        name: groupName,
        maxMembers,
      });
      if (data.success) {
        toast.success("Group Created");
        setGroupName("");
        setMaxMembers(5);
        loadGroups();
      }
    } catch (error) {
      toast.error("Group Creation Failed");
    }
  };

  // -----------------------------
  // ADD MEMBERS TO GROUP
  // -----------------------------
  const addMembers = async (groupId) => {
    if (selectedUsers.length === 0) {
      return toast.error("Select at least 1 user!");
    }
    try {
      const { data } = await axios.post(`${BackendUrl}/api/admin/groups/${groupId}/add-users`, {
        userIds: selectedUsers,
      });
      if (data.success) {
        toast.success("Users added to group");
        setSelectedUsers([]);
        loadGroups();
      }
    } catch (error) {
      toast.error("Failed to add users");
    }
  };

  // -----------------------------
  // TOGGLE USER SELECTION
  // -----------------------------
  const toggleUser = (userId) => {
    setSelectedUsers((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    );
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Admin Group Manager</h1>
      <button
  className="mb-6 w-full sm:w-64 py-3 bg-green-600 text-white rounded-lg"
  onClick={() => navigate("/admin/report")}
>
  View Collected Data
</button>

      {/* CREATE GROUP */}
      <div className="bg-white p-6 rounded-xl shadow-md mb-10 max-w-xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">Create New Group</h2>
        <form onSubmit={handleCreateGroup} className="space-y-4">
          <input
            type="text"
            placeholder="Group Name"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            className="w-full p-3 border rounded-lg"
            required
          />
          <input
            type="number"
            placeholder="Max Members"
            value={maxMembers}
            onChange={(e) => setMaxMembers(e.target.value)}
            className="w-full p-3 border rounded-lg"
            required
            min="1"
          />
          <button className="w-full py-3 bg-indigo-600 text-white rounded-lg">
            Create Group
          </button>
        </form>
      </div>

      {/* SELECT USERS */}
      <div className="bg-white p-6 rounded-xl shadow-md mb-10 max-w-3xl mx-auto">
        <h2 className="text-xl font-semibold mb-4">Select Users</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {users.map((user) => (
            <button
              key={user._id}
              onClick={() => toggleUser(user._id)}
              className={`p-3 rounded-lg border text-sm ${
                selectedUsers.includes(user._id) ? "bg-indigo-600 text-white" : "bg-gray-100"
              }`}
            >
              {user.name}
            </button>
          ))}
        </div>
      </div>

      {/* GROUP LIST */}
      <div className="max-w-4xl mx-auto space-y-6">
        {groups.map((group) => (
          <div key={group._id} className="bg-white p-6 rounded-xl shadow-md">
            <h3 className="text-lg font-bold">
              {group.name} — {group.members.length}/{group.maxMembers} members
            </h3>
            <div className="flex flex-wrap mt-2 gap-2">
              {group.members.map((m) => (
                <span key={m._id} className="px-3 py-1 bg-green-200 rounded-full">
                  {m.name}
                </span>
              ))}
            </div>
            <button
              className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg"
              onClick={() => addMembers(group._id)}
            >
              Add Selected Users
            </button>
          </div>
        ))}
      </div>
      

    </div>
    
  );
}

export default VerifyEmail;
