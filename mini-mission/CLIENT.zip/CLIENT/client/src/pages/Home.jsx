import React from 'react'
import NavBar from '../Components/NavBar'
import Header from '../Components/Header'

function Home() {
  return (
    <div className=' items-center min-h-screen justify-center bg-[url("/bg_img.png")] bg-cover bg-center'>
        <NavBar/>
        <Header />
    </div>
  )
}

export default Home