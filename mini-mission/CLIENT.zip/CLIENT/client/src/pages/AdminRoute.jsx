function AdminRoute() {
  const { isLoggedin, userData } = useContext(AppContent);

  if(!isLoggedin) return <Navigate to="/login" />;
  if(!userData?.role || userData.role !== "admin") return <Navigate to="/" />;

  return <Outlet />;
}

export default AdminRoute;